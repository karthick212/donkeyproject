<template>
  <div id="app">
    <Header v-if="checkLogin"></Header>
    <Sidebar v-if="checkLogin"></Sidebar>
    <router-view/>
  </div>
</template>
<script>
import Header from './components/Header.vue' 
import Sidebar from './components/Sidebar.vue'

export default {
  name: 'App',
  data: function(){
    return{
      checkLogin:boolean
    }
  },
  components: {
    Header,
    Sidebar
  },
  created(){
    var currentUrl = window.location.pathname;
    if(currentUrl == "/login"){
      this.checkLogin = false;
    }else{
      this.checkLogin = true;
    }
  }
}
</script>

<style >
@import './assets/css/adminlte.css';
</style>
