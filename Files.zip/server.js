const express = require("express");
const body_parser = require("body-parser");
const cors = require("cors");
const morgan = require("morgan");
const jwt = require('jsonwebtoken');
const path = require('path');
const app = express();

const api_admin = require("./server/routes/admin");
// const api_driver = require("./routes/driver");


// app.use(morgan("combine"));

app.use(express.static((__dirname, './dist/')));

// app.use(bodyParser.urlencoded({ extended: true }));
app.use(body_parser.json());
app.use(cors());

app.use('/api/admin/', api_admin);

app.get('*',(req,res) => {
    res.sendfile(__dirname + "/dist/index.html")

});


// app.use('/api/diver',api_driver);

app.listen(process.env.PORT || 8080);
